/**
 * AI Client Service for QuizGenius
 * Securely communicates with the backend AI endpoints.
 * Never exposes AI API keys in the client browser.
 */

export const CLIENT_BRANCH_SUBJECTS = {
  "Computer Science Engineering": {
    recommendedLanguages: ["C", "C++", "Java", "Python"],
    recommendedSubjects: [
      "Data Structures",
      "Algorithms",
      "DBMS",
      "Operating Systems",
      "Computer Networks",
      "Web Development"
    ],
    learningPath: "Master programming fundamentals, data structures, algorithms, and core computer science systems."
  },
  "Information Technology": {
    recommendedLanguages: ["Java", "Python", "SQL", "Web Development"],
    recommendedSubjects: [
      "Software Engineering",
      "Computer Networks",
      "Cloud Computing",
      "Database Management"
    ],
    learningPath: "Focus on enterprise web systems, SQL data management, software engineering, and cloud infrastructure."
  },
  "Artificial Intelligence & Machine Learning": {
    recommendedLanguages: ["Python", "TensorFlow"],
    recommendedSubjects: [
      "Artificial Intelligence",
      "Machine Learning",
      "Deep Learning",
      "Statistics",
      "Mathematics for AI/ML",
      "Data Structures"
    ],
    learningPath: "Master neural networks, machine learning algorithms, deep learning architectures, and statistical mathematics."
  },
  "Data Science": {
    recommendedLanguages: ["Python", "SQL"],
    recommendedSubjects: [
      "Statistics",
      "NumPy",
      "Pandas",
      "Data Analysis",
      "Machine Learning",
      "Data Visualization"
    ],
    learningPath: "Master exploratory data analytics, NumPy/Pandas processing, SQL querying, and predictive modeling."
  },
  "Electronics & Telecommunication": {
    recommendedLanguages: ["Embedded C", "MATLAB", "Verilog"],
    recommendedSubjects: [
      "Digital Electronics",
      "Analog Electronics",
      "Microcontrollers",
      "Embedded Systems",
      "Communication Systems"
    ],
    learningPath: "Focus on embedded firmware, digital logic synthesis, microcontrollers, and communication systems."
  },
  "Electrical Engineering": {
    recommendedLanguages: ["MATLAB", "Simulink", "PLC"],
    recommendedSubjects: [
      "Circuit Theory",
      "Electrical Machines",
      "Power Systems",
      "Control Systems",
      "Power Electronics"
    ],
    learningPath: "Focus on power grid dynamics, electrical machines, circuit theory, and industrial PLC control."
  },
  "Mechanical Engineering": {
    recommendedLanguages: ["MATLAB", "AutoCAD", "SolidWorks"],
    recommendedSubjects: [
      "Engineering Mechanics",
      "Thermodynamics",
      "Strength of Materials",
      "Manufacturing Processes",
      "Fluid Mechanics"
    ],
    learningPath: "Master CAD modeling, strength of materials, thermodynamic cycles, and manufacturing processes."
  },
  "Civil Engineering": {
    recommendedLanguages: ["AutoCAD", "STAAD.Pro"],
    recommendedSubjects: [
      "Surveying",
      "Structural Engineering",
      "Geotechnical Engineering",
      "Construction Engineering",
      "Environmental Engineering",
      "Transportation Engineering"
    ],
    learningPath: "Focus on structural analysis, civil drafting, geotechnical soil mechanics, and infrastructure design."
  },
  "Chemical Engineering": {
    recommendedLanguages: ["MATLAB", "Aspen Plus"],
    recommendedSubjects: [
      "Chemical Thermodynamics",
      "Fluid Mechanics",
      "Heat Transfer",
      "Mass Transfer",
      "Chemical Reaction Engineering",
      "Process Control"
    ],
    learningPath: "Focus on transport phenomena, reaction kinetics, chemical thermodynamics, and process automation."
  }
};

export function canonicalClientBranch(branch) {
  const b = (branch || "").trim().toLowerCase();
  if (b.includes("chem")) return "Chemical Engineering";
  if (b.includes("data sci") || b === "ds") return "Data Science";
  if (b.includes("ai") || b.includes("aiml") || b.includes("artificial") || b.includes("machine learn")) {
    return "Artificial Intelligence & Machine Learning";
  }
  if ((b.includes("elec") && b.includes("tele")) || b.includes("e&tc") || b.includes("entc") || b.includes("etc")) {
    return "Electronics & Telecommunication";
  }
  if (b.includes("elec") || b.includes("eee")) return "Electrical Engineering";
  if (b.includes("mech")) return "Mechanical Engineering";
  if (b.includes("civil")) return "Civil Engineering";
  if (b.includes("info") || b === "it") return "Information Technology";
  return "Computer Science Engineering";
}

export async function fetchBranchRecommendations(branch) {
  const canon = canonicalClientBranch(branch);
  const fallback = CLIENT_BRANCH_SUBJECTS[canon] || CLIENT_BRANCH_SUBJECTS["Computer Science Engineering"];

  try {
    const res = await fetch("/api/ai/recommend-subjects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ branch: canon })
    });
    if (!res.ok) throw new Error("Failed to fetch AI subject recommendations");
    const data = await res.json();
    return {
      branch: canon,
      recommendedLanguages: data.recommendedLanguages || fallback.recommendedLanguages,
      recommendedSubjects: data.recommendedSubjects || fallback.recommendedSubjects,
      allSubjects: data.allSubjects || [...(data.recommendedLanguages || fallback.recommendedLanguages), ...(data.recommendedSubjects || fallback.recommendedSubjects)],
      learningPath: data.learningPath || fallback.learningPath,
      isAiGenerated: Boolean(data.isAiGenerated)
    };
  } catch (err) {
    console.warn("AI recommendation network fallback:", err);
    return {
      branch: canon,
      recommendedLanguages: [...fallback.recommendedLanguages],
      recommendedSubjects: [...fallback.recommendedSubjects],
      allSubjects: [...fallback.recommendedLanguages, ...fallback.recommendedSubjects],
      learningPath: fallback.learningPath,
      isAiGenerated: false
    };
  }
}

export async function fetchQuizQuestions(subject, difficulty = "Medium", count = 10, previousQuestions = [], branch = "") {
  try {
    const res = await fetch("/api/ai/generate-quiz", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subject, difficulty, count, previousQuestions, branch })
    });
    if (!res.ok) throw new Error("Failed to generate AI quiz questions");
    return await res.json();
  } catch (err) {
    console.warn("AI quiz generation error, falling back:", err);
    throw err;
  }
}

export async function fetchAptitudeQuestions(section, topic, difficulty = "Medium", count = 10, previousQuestions = []) {
  try {
    const res = await fetch("/api/ai/generate-aptitude", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ section, topic, difficulty, count, previousQuestions })
    });
    if (!res.ok) throw new Error("Failed to generate AI aptitude questions");
    return await res.json();
  } catch (err) {
    console.warn("AI aptitude generation error, falling back:", err);
    throw err;
  }
}

export async function fetchGateQuestions(subject, difficulty = "Medium", count = 10, previousQuestions = [], branch = "Computer Science Engineering") {
  try {
    const res = await fetch("/api/ai/generate-gate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subject, difficulty, count, previousQuestions, branch })
    });
    if (!res.ok) throw new Error("Failed to generate AI GATE questions");
    return await res.json();
  } catch (err) {
    console.warn("AI GATE generation error, falling back:", err);
    throw err;
  }
}

export async function fetchPerformanceAnalysis(payload) {
  try {
    const res = await fetch("/api/ai/analyze-performance", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error("Failed to generate performance analysis");
    return await res.json();
  } catch (err) {
    console.warn("AI analysis error:", err);
    const pct = Math.round((payload.score / (payload.totalQuestions || 1)) * 100);
    return {
      strongAreas: ["Core Concepts", "Standard Implementations"],
      needsPractice: ["Edge Cases", "Speed & Time Optimization"],
      recommendation: `Target ${payload.subject} practice tests focusing on problem edge cases before progressing to hard difficulty.`,
      summary: `Completed with ${pct}% score across ${payload.totalQuestions} questions.`,
      accuracyRate: `${pct}%`
    };
  }
}
